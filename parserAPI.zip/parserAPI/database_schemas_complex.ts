export class Sample{
    arr : Array<String>
    constructor(){
        this.arr = [];
        this.arr.push("0");
        this.arr.push("5");
    }
}