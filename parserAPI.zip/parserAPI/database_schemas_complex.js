"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sample = void 0;
class Sample {
    arr;
    constructor() {
        this.arr = [];
        this.arr.push("0");
        this.arr.push("5");
    }
}
exports.Sample = Sample;
